<?php
/*
Plugin Name: Custom Select Widget
Description: A custom widget to display different select fields.
Version: 1.0
Author: Malik Tayyab 
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Load the Elementor widget
function register_custom_select_widget_elementor() {
    // Check if Elementor is active and loaded
    if (did_action('elementor/loaded')) {
        // Register the widget
        require_once(plugin_dir_path(__FILE__) . 'elementor-custom-select-widget.php');
    }
}
add_action('elementor/widgets/widgets_registered', 'register_custom_select_widget_elementor');

// Add custom category
function add_custom_category($elements_manager) {
    $elements_manager->add_category(
        'custom-widgets',
        [
            'title' => __('Custom Widgets', 'text_domain'),
            'icon' => 'fa fa-plug',
        ]
    );
}
add_action('elementor/elements/categories_registered', 'add_custom_category');
?>
