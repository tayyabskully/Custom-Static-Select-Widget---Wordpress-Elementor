<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Elementor_Custom_Select_Widget extends Widget_Base {

    public function get_name() {
        return 'custom_select_widget';
    }

    public function get_title() {
        return __('Custom Select Widget', 'text_domain');
    }

    public function get_icon() {
        return 'eicon-select';
    }

    public function get_categories() {
        return ['custom-widgets'];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'text_domain'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => __('Title', 'text_domain'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Custom Select Widget', 'text_domain'),
            ]
        );

        $this->add_control(
            'label',
            [
                'label' => __('Label', 'text_domain'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Select an Option:', 'text_domain'),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'option_value',
            [
                'label' => __('Option Value', 'text_domain'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Option', 'text_domain'),
            ]
        );

        $this->add_control(
            'select_options',
            [
                'label' => __('Select Options', 'text_domain'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'option_value' => __('Option 1', 'text_domain'),
                    ],
                    [
                        'option_value' => __('Option 2', 'text_domain'),
                    ],
                ],
                'title_field' => '{{{ option_value }}}',
            ]
        );

        $this->end_controls_section();

        // Start Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Style', 'text_domain'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'heading_color',
            [
                'label' => __('Heading Color', 'text_domain'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} h3' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'label_color',
            [
                'label' => __('Label Color', 'text_domain'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} label' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'label' => __('Heading Typography', 'text_domain'),
                'selector' => '{{WRAPPER}} h3',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'label_typography',
                'label' => __('Label Typography', 'text_domain'),
                'selector' => '{{WRAPPER}} label',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'background',
                'label' => __('Background', 'text_domain'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .custom-select-widget',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'border',
                'label' => __('Border', 'text_domain'),
                'selector' => '{{WRAPPER}} .custom-select-widget',
            ]
        );

        $this->add_responsive_control(
            'padding',
            [
                'label' => __('Padding', 'text_domain'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .custom-select-widget' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'margin',
            [
                'label' => __('Margin', 'text_domain'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .custom-select-widget' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
        // End Style Section

        // Start Dropdown Style Section
        $this->start_controls_section(
            'dropdown_style_section',
            [
                'label' => __('Dropdown Style', 'text_domain'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'dropdown_background_color',
            [
                'label' => __('Dropdown Background Color', 'text_domain'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} select' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'dropdown_text_color',
            [
                'label' => __('Dropdown Text Color', 'text_domain'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} select' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'dropdown_border',
                'label' => __('Dropdown Border', 'text_domain'),
                'selector' => '{{WRAPPER}} select',
            ]
        );

        $this->add_responsive_control(
            'dropdown_padding',
            [
                'label' => __('Dropdown Padding', 'text_domain'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} select' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'dropdown_margin',
            [
                'label' => __('Dropdown Margin', 'text_domain'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} select' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
        // End Dropdown Style Section
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        echo '<div class="custom-select-widget">';
        if (!empty($settings['title'])) {
            echo '<h3>' . esc_html($settings['title']) . '</h3>';
        }

        if (!empty($settings['select_options'])) {
            echo '<form action="" method="post">';
            echo '<label for="custom-select">' . esc_html($settings['label']) . '</label>';
            echo '<select name="custom-select" id="custom-select">';
            foreach ($settings['select_options'] as $option) {
                echo '<option value="' . esc_attr($option['option_value']) . '">' . esc_html($option['option_value']) . '</option>';
            }
            echo '</select>';
            echo '</form>';
        }

        echo '</div>';
    }

    protected function content_template() {
        ?>
        <#
        view.addInlineEditingAttributes('title', 'none');
        view.addInlineEditingAttributes('label', 'none');
        #>
        <div class="custom-select-widget">
            <h3 {{{ view.getRenderAttributeString('title') }}}>{{{ settings.title }}}</h3>
            <form action="" method="post">
                <label for="custom-select">{{{ settings.label }}}</label>
                <select name="custom-select" id="custom-select">
                    <# _.each(settings.select_options, function(option) { #>
                        <option value="{{ option.option_value }}">{{ option.option_value }}</option>
                    <# }); #>
                </select>
            </form>
        </div>
        <?php
    }
}

\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Elementor_Custom_Select_Widget());
?>
